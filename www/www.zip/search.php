<?php


$arr = array(
	'param1'=>'value1',
	'param2'=>'value2',
);
echo json_encode($arr);
?>